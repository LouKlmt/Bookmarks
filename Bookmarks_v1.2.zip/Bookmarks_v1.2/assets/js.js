$(document).ready(function(){
	$(".toolbox_toggler .tool").click(function(){
		if ($(".toolbox").css("display") === "none"){
			$(".toolbox").css("display","block");
		}else{
			$(".toolbox").css("display","none");
		}
	});
	$(document).on("click", function(e){
		if($(".toolbox_toggler") !== e.target && !$(".toolbox_toggler").has(e.target).length && $(".toolbox").css("display") === "block"){
			$(".toolbox").hide();
		}            
	});

	loadfromlocalstorage('note', 'note_content');


	$('#color-input-theme').on('input', function() {
		$('#themecolorinput').val(this.value);
	});
	$('#themecolorinput').on('input', function() {
		$('#color-input-theme').val(this.value);
	});

	$('#color-input-theme-hover').on('input', function() {
		$('#themehovercolorinput').val(this.value);
	});
	$('#themehovercolorinput').on('input', function() {
		$('#color-input-theme-hover').val(this.value);
	});

	$('#color-input-note').on('input', function() {
		$('#notecolorinput').val(this.value);
	});
	$('#notecolorinput').on('input', function() {
		$('#color-input-note').val(this.value);
	});

	$('#color-input-bookmarks').on('input', function() {
		$('#bookmarkscolorinput').val(this.value);
	});
	$('#bookmarkscolorinput').on('input', function() {
		$('#color-input-bookmarks').val(this.value);
	});

	$('#color-input-bookmarksbg').on('input', function() {
		$('#bookmarksbgcolorinput').val(convertHex2Rgb(this.value, $('#opacity-input-bookmarksbg').val()));
		$('.sample-bookmarksbg').css('background', convertHex2Rgb(this.value, $('#opacity-input-bookmarksbg').val()));
	});
	$('#bookmarksbgcolorinput').on('input', function() {
		$('#color-input-bookmarksbg').val(convertRgb2Hex(this.value));
		$('.sample-bookmarksbg').css('background', convertRgb2Hex(this.value));
	});

	$('#opacity-input-bookmarksbg').on('input', function() {
		$('#bookmarksbgcolorinput').val(convertHex2Rgb($('#color-input-bookmarksbg').val(), this.value));
		$('.sample-bookmarksbg').css('background', convertHex2Rgb($('#color-input-bookmarksbg').val(), this.value));
	});
	$('#bookmarksbgcolorinput').on('input', function() {
		$('#opacity-input-bookmarksbg').val(convertRgb2opacity($('#bookmarksbgcolorinput').val()));
		$('.sample-bookmarksbg').css('background', $('#bookmarksbgcolorinput').val());
	});

});



function convertRgb2opacity(rgb){
rgb = rgb.replace('rgba(', '');
rgb = rgb.replace('rgb(', '');
rgb = rgb.replace(')', '');
let rgb_arr = rgb.split(',');
let opacity = rgb_arr[3]*100;
return opacity;
}

function convertRgb2Hex(rgb){
rgb = rgb.replace('rgba(', '');
rgb = rgb.replace('rgb(', '');
rgb = rgb.replace(')', '');
let hex_arr = rgb.split(',');
let hex_value = '#'+parseInt(hex_arr[0]).toString(16)+parseInt(hex_arr[1]).toString(16)+parseInt(hex_arr[2]).toString(16);
return hex_value;
}

function convertHex2Rgb(hex,opacity){
    hex = hex.replace('#','');
    let r = parseInt(hex.substring(0,2), 16);
    let g = parseInt(hex.substring(2,4), 16);
    let b = parseInt(hex.substring(4,6), 16);

    let result = 'rgba('+r+','+g+','+b+','+opacity/100+')';
    return result;
}

function deleteridirect(id, image, elementid, type){
	if (image === false) {
		window.location.replace("assets/functions.php?"+type+"="+id);
	}else{
		window.location.replace("assets/functions.php?"+type+"="+id+"&image="+image);
	}
}

function deleteElement(id, image, elementid, type){
	let timeout;
	elementid = $.escapeSelector(elementid);
	if ($('#'+elementid).attr("background") !== "red") {
		$('#'+elementid).css("background", "red");
		$('#'+elementid+' i').attr("class", "fa fa-hourglass-half");
		$('#'+elementid).attr("onclick", "deleteridirect('"+id+"', '"+image+"', '"+elementid+"', '"+type+"')");
		timeout = setTimeout(function(){
			$('#'+elementid).attr("onclick", "deleteElement('"+id+"', '"+image+"', '"+elementid+"', '"+type+"')");
			$('#'+elementid+' i').attr("class", "fa fa-times");
			$('#'+elementid).css("background", "white");
		}, 5000);
	}
}


function resetindex(){
	window.location.href = "index.php";
}

function toggledropdown(togglerid, elementid){
	if ($('#'+elementid).css("display") !== "block") {
		$('#'+elementid).css("display", "block");
	}else{
		$('#'+elementid).css("display", "none");
	}
}

function togglebookmarkanimation(togglerid, elementid){
	if ($('#'+elementid).css("display") !== "block") {
		$('#'+togglerid).css("transition","0.3s ease-in-out");
		$('#'+togglerid).css("transform","rotate(180deg)");
	}else{
		$('#'+togglerid).css("transition","0.3s ease-in-out");
		$('#'+togglerid).css("transform","rotate(0deg)");
	}
	toggledropdown(togglerid, elementid);
}

function toggleportalanimation(togglerid, elementid){
	if ($('#'+elementid).css("display") !== "block") {
		$('#'+togglerid).css("transition","0.3s ease-in-out");
		$('#'+togglerid).css("transform","rotate(-75deg)");
	}else{
		$('#'+togglerid).css("transition","0.3s ease-in-out");
		$('#'+togglerid).css("transform","rotate(-90deg)");
	}
	toggledropdown(togglerid, elementid);
}

$(document).on("click", function(e){
	if($(".top-left-menu-container") !== e.target && !$(".top-left-menu-container").has(e.target).length && $("#top-left-menu-dropdown").css("display") === "block"){
		$("#top-left-menu-dropdown").hide();
		$("#top-left-menu-dropdown-toggler").css("transition","0.3s ease-in-out");
		$("#top-left-menu-dropdown-toggler").css("transform","rotate(0deg)");
	}            
});


function savetolocalstorage(elementid, storagename, text){
	if (elementid.length > 0) {
		localStorage.setItem(storagename, $("#"+elementid).val());
	}else{
		localStorage.setItem(storagename, text);
	}
}

function loadfromlocalstorage(elementid, storagename){
	if (localStorage.getItem(storagename).length > 0) {
		$("#"+elementid).val(localStorage.getItem(storagename));
	}
}
