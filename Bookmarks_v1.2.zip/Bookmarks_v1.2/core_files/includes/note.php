<div class="content note">
<textarea id="note" onkeyup="savetolocalstorage('note', 'note_content')">
	
</textarea>	
</div>