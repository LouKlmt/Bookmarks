<?php
session_start();

$DP_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "bookmarks";



if (isset($_POST["uploadWidgetImage"]) && isset($_POST["href"]) && isset($_POST["name"])) {
	if ($_POST["uploadWidgetImage"] != "" && $_POST["href"] != "" && $_POST["name"] != "") {
		$msg = "";
		$currentimage = "";
		$targetdir = $_POST["targetdir"];
		$filename = basename($_FILES["filetoupload"]["name"]);
		$name = $_POST["name"];
		$href = $_POST["href"];
		if (isset($_POST["sort_order"])) {
			$sort_order = $_POST["sort_order"];
		}
		$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
		if ($con->connect_error) {
			$error = "Failed to connect to MySQL: " . mysqli_connect_error();
		}

		if (!isset($error)) {
			$query = "CREATE TABLE IF NOT EXISTS widgets (
			id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(300) NOT NULL,
			href VARCHAR(300) NOT NULL,
			image VARCHAR(300) NOT NULL,
			sort_order INT(6)
		)";
		if ($con->query($query) != TRUE) {
			$error = "Error creating table: " . $conn->error;
		}
	}

	if (!isset($error)) {
		/*echo $targetdir.$filename; */

		if (strlen(basename($_FILES["filetoupload"]["name"])) > 0) {

			$check = getimagesize($_FILES["filetoupload"]["tmp_name"]);
			if(!isset($error) && $check == false) {
				$error = "file is not an image";
			}

			if (!isset($error) && file_exists($targetdir.$filename)) {
				$error = "Image already exists.";
			}

			if (!isset($error)) {
				if (move_uploaded_file($_FILES["filetoupload"]["tmp_name"], $targetdir.$filename)) {
					$msg .= "The file ". htmlspecialchars( basename( $_FILES["filetoupload"]["name"])). " has been uploaded. ";
				} else {
					$error = "Sorry, there was an error uploading your file.";
				}
			}

		}else{
			$error = "empty file";
		}
	}

	if (!isset($error)) {
		$query = "SELECT * FROM widgets WHERE name = '$name' OR href = '$href' OR image = '$filename'";
		$result = $con->query($query);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				if ($row["name"] == $_POST["name"]) {
					$error = "name of widget allready exists";
				}else if ($row["href"] == $_POST["href"]) {
					$error = "href of widget allready exists";
				}else if ($row["image"] == $filename) {
					$error = "image name of widget allready exists";
				}
			}
		}
	}

	if (!isset($error)) {
		if (isset($sort_order)) {
			$query = "INSERT INTO widgets (name, href, image, sort_order) VALUES ('".$name."', '".$href."', '".$filename."', '".$sort_order."')";
		}else{
			$query = "INSERT INTO widgets (name, href, image) VALUES ('".$name."', '".$href."', '".$filename."')";
		}
		if ($con->query($query) != TRUE) {
			$error = "Error inserting data: " . $conn->error;
		}else{
			$msg .= "Data inserted to DB successfully. ";
		}
	}

	

}else{
	$error = "empty fields";
}
$con->close();
if (!isset($error)) {
	header("Location: ../index.php?msg=".$msg);
}else{
	header("Location: ../index.php?error=".$error);
}
}



if (isset($_GET['deletewidgetid']) && isset($_GET['image'])) {
	$msg = "";
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	if(!isset($error)){
		$query = "DELETE FROM widgets WHERE id = ".$_GET['deletewidgetid'];
		if ($con->query($query) != TRUE) {
			$error = "Error deleting from table: " . $conn->error;
		}else{
			$msg .= "row deleted from table";
		}
	}
	$con->close();
	if (file_exists("images/widgets/".$_GET['image'])) {
		unlink("images/widgets/".$_GET['image']);
	}

	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}
}




if (isset($_POST["addbookmark"]) && isset($_POST["href"]) && isset($_POST["name"])) {
	
	if ($_POST["href"] != "" && $_POST["name"] != "") {
		$msg = "";
		$name = $_POST["name"];
		$href = $_POST["href"];
		if (isset($_POST["sort_order"])) {
			$sort_order = $_POST["sort_order"];
		}else{
			$sort_order = "";
		}

		$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
		if ($con->connect_error) {
			$error = "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		if(!isset($error)){
			$query = "CREATE TABLE IF NOT EXISTS bookmarks (
			id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(300) NOT NULL,
			href VARCHAR(300) NOT NULL,
			sort_order INT(6)
		)";
		if ($con->query($query) != TRUE) {
			$error = "Error creating table: " . $conn->error;
		}
	}

	if (!isset($error)) {
		$query = "SELECT * FROM bookmarks WHERE name = '$name' OR href = '$href'";
		$result = $con->query($query);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				if ($row["name"] == $name) {
					$error = "name of bookmark allready exists";
				}else if ($row["href"] == $href) {
					$error = "href of bookmark allready exists";
				}
			}
		}
	}

	if (!isset($error)) {
		$query = "INSERT INTO bookmarks (name, href, sort_order) VALUES ('".$name."', '".$href."', '".$sort_order."')";
		if ($con->query($query) != TRUE) {
			$error = "Error inserting data: " . $conn->error;
		}else{
			$msg .= "Data inserted to DB successfully. ";
		}
	}



	$con->close();
}else{
	$error = "Empty Fields";
}

if (isset($error)) {
	header("Location: ../index.php?error=".$error);
}else{
	header("Location: ../index.php?msg=".$msg);
}
}


if (isset($_GET['deletebookmarkid']) && $_GET['deletebookmarkid'] != "") {
	$msg = '';
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	if (!isset($error)) {
		$query="DELETE FROM bookmarks WHERE id = ".$_GET['deletebookmarkid'];
		if ($con->query($query) != TRUE) {
			$error = "Error deleting data: " . $conn->error;
		}else{
			$msg .= "Data deleted from DB successfully. ";
		}
	}
	$con->close();
	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}
}


if (isset($_POST['change_color'])) {
	if ($_POST['color'] == "") {
		$error = "Empty Data";
	}
	if ($_POST['colorhover'] == "") {
		$error = "Empty Data";
	}
	$msg = '';
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	if (!isset($error)) {
		if(insertintosettings($con, "color", $_POST['color'])){
			$msg .= "Color iserted to DB successfully. ";
		}else{
			$error = "Error inserting text color data: " . $conn->error;
		}
	}

	if (!isset($error)) {
		if(insertintosettings($con, "colorhover", $_POST['colorhover'])){
			$msg .= "Color Hover iserted to DB successfully. ";
		}else{
			$error = "Error inserting text color hover data: " . $conn->error;
		}
	}
	$con->close();
	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}
}


if (isset($_POST['change_notecolor'])) {
	if ($_POST['notecolor'] == "") {
		$error = "Empty Data";
	}
	$msg = '';
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	if (!isset($error)) {
		if(insertintosettings($con, "notecolor", $_POST['notecolor'])){
			$msg .= "Color iserted to DB successfully. ";
		}else{
			$error = "Error inserting text color data: " . $conn->error;
		}
	}
	$con->close();
	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}
}


if (isset($_POST['change_bookmarkscolor'])) {
	if ($_POST['bookmarkstextcolor'] == "" || $_POST['bookmarksbackground'] == "") {
		$error = "Empty Data";
	}
	$msg = '';
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	if (!isset($error)) {
		if(insertintosettings($con, 'bookmarkstextcolor', $_POST['bookmarkstextcolor'])){
			$msg .= "Text color iserted to DB successfully. ";
		}else{
			$error = "Error inserting text color data: " . $conn->error;
		}
	}
	if (!isset($error)) {
		if(insertintosettings($con, 'bookmarksbackground', $_POST['bookmarksbackground'])){
			$msg .= "Background color iserted to DB successfully. ";
		}else{
			$error = "Error inserting background data: " . $conn->error;			
		}
	}
	$con->close();
	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}

}

if (isset($_POST['change_mainbackground'])) {
	$msg = "";
	$currentbackground = "";
	$targetdir = $_POST["targetdir"];
	$filename = basename($_FILES["filetoupload"]["name"]);
	$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	if ($con->connect_error) {
		$error = "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	if (!isset($error)) {

		if (strlen(basename($_FILES["filetoupload"]["name"])) > 0) {

			$check = getimagesize($_FILES["filetoupload"]["tmp_name"]);
			if(!isset($error) && $check == false) {
				$error = "file is not an image";
			}

			if (!isset($error) && file_exists($targetdir.$filename)) {
				unlink($targetdir.$filename);
				$msg .= "Image replaced. ";
			}

			if (!isset($error)) {
				$query = "SELECT mainbackground FROM settings";
				$result = $con->query($query);
				if ($result != false && $result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						$currentbackground = $row['mainbackground'];
					}
				}
				if ($currentbackground != "" && file_exists($targetdir.$currentbackground)){
					unlink($targetdir.$currentbackground);
					$msg .= "Previous image '$currentbackground' deleted. ";
				}
			}

			if (!isset($error)) {
				if (move_uploaded_file($_FILES["filetoupload"]["tmp_name"], $targetdir.$filename)) {
					$msg .= "The file ". htmlspecialchars( basename( $_FILES["filetoupload"]["name"])). " has been uploaded. ";
				} else {
					$error = "Sorry, there was an error uploading your file.";
				}
			}

		}else{
			$error = "empty file";
		}
	}

	if (!isset($error)) {
		if(insertintosettings($con, 'mainbackground', $filename)){
			$msg .= "Data iserted to DB successfully. ";
		}else{
			$error = "Error inserting data: " . $conn->error;
		}
	}
	$con->close();
	if (isset($error)) {
		header("Location: ../index.php?error=".$error);
	}else{
		header("Location: ../index.php?msg=".$msg);
	}
}



function insertintosettings($con, $collumn, $value){
	$query="SELECT $collumn FROM settings";
	$result = $con->query($query);
	if ($result != false && $result->num_rows > 0) {
		$query = "UPDATE settings SET $collumn='".$value."'";
		$result = $con->query($query);
	}else{
		$query = "CREATE TABLE IF NOT EXISTS settings (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		color VARCHAR(300),
		notecolor VARCHAR(300),
		bookmarkstextcolor VARCHAR(300),
		bookmarksbackground VARCHAR(300),
		mainbackground VARCHAR(300)
	)";
	$result = $con->query($query);
	$query = "INSERT INTO settings ($collumn) VALUES ('".$value."')";
	$result = $con->query($query);
}
if ($result != TRUE) {
	return false;
}else{
	return true;
}
}


?>