<div class="top-left-menu-container">
	<div class="top-left-menu-inner-container">
	<button id="top-left-menu-dropdown-toggler" onclick="togglebookmarkanimation('top-left-menu-dropdown-toggler', 'top-left-menu-dropdown');"><i class="fa fa-circle-o-notch" aria-hidden="true"></i></button>
	<div id="top-left-menu-dropdown" class="top-left-menu-dropdown">
		<table>
		<?php

		$query = "SELECT * FROM bookmarks ORDER BY sort_order ASC";
		$result = $con->query($query);

		if ($result != false && $result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				?>
				
					<tr>
						<td>
							<a href="<?php echo $row['href'] ?>" target="_blank"><?php echo $row['name'] ?><i class="fa fa-share" aria-hidden="true"></i></a>
						</td>
					</tr>
				
				<?php
			}
		}

		?>
		</table>
	</div>
	</div>
</div>