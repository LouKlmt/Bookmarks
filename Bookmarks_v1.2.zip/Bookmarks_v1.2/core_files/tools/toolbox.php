<div class="tools">
	<div class="tool_container">
		<h1>Toolbox</h1>
		<h2>Manage Widgets</h2><br />
		<h3>Create Widget</h3>
		<div class="tool_container">
			<form action="assets/functions.php" name="uploadWidgetImage" method="post" enctype="multipart/form-data">

				<div class="input_control">
					<label for="filetoupload">Image</label>
					<input type="file" name="filetoupload" accept="image">
					<br />
				</div>
				<div class="input_control">
					<label for="name">Name</label>
					<input type="text" name="name">
					<br />
				</div>
				<div class="input_control">
					<label for="href">URL</label>
					<input type="text" name="href">
					<br />
				</div>
				<div class="input_control">
					<label for="sort_order">Sort Order</label>
					<input type="number" name="sort_order">
					<br />
				</div>
				<input type="checkbox" name="uploadWidgetImage" checked="true" style="display: none;">
				<input type="text" name="targetdir" value="images/widgets/" style="display: none;">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

		<div class="tool_container">
			<h3>Delete Widgets</h3>
			<?php

			$query = "SELECT * FROM widgets ORDER BY sort_order ASC";
			$result = $con->query($query);

			if ($result != false && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) { ?>
					<div class="button_control">

						<button id="<?php echo str_replace(' ', '_', 'widget-'.$row['name'].'-'.$row['id']); ?>" name="<?php echo $row['name']; ?>" onclick="deleteElement(<?php echo '\''.$row['id'].'\'' ?>, <?php echo '\''.$row['image'].'\'' ?>, <?php echo '\''.str_replace(' ', '_', 'widget-'.$row['name'].'-'.$row['id']).'\''; ?>, 'deletewidgetid')"><i class="fa fa-times"></i><p><?php echo $row['name']; ?></p></button>
					</div>
					<?php
				}
			}
			?>
		</div>

		<h2>Manage Bookmarks</h2>
		<div class="tool_container">
			<h3>Add Bookmark</h3>
			<form action="assets/functions.php" name="addbookmark" method="post" enctype="multipart/form-data">
				<div class="input_control">
					<label for="name">Name</label>
					<input type="text" name="name">
					<br />					
				</div>
				<div class="input_control">
					<label for="href">URL</label>
					<input type="text" name="href">
					<br />					
				</div>
				<div class="input_control">
					<label for="sort_order">Sort Order</label>
					<input type="number" name="sort_order">
					<br />
				</div>
				<input type="checkbox" name="addbookmark" style="display: none;" checked="true">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

		<div class="tool_container">
			<h3>Delete Bookmarks</h3>
			<?php

			$query = "SELECT * FROM bookmarks ORDER BY sort_order ASC";
			$result = $con->query($query);

			if ($result != false && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) { ?>
					<div class="button_control">

						<button id="<?php echo str_replace(' ', '_', 'bookmark-'.$row['name'].'-'.$row['id']); ?>" name="<?php echo $row['name']; ?>" onclick="deleteElement(<?php echo '\''.$row['id'].'\'' ?>, false, <?php echo '\''.str_replace(' ', '_', 'bookmark-'.$row['name'].'-'.$row['id']).'\''; ?>, 'deletebookmarkid')"><i class="fa fa-times"></i><p><?php echo $row['name']; ?></p></button>
					</div>
					<?php
				}
			}
			?>
		</div>
		
		<h2>Manage View Settings</h2>
		<div class="tool_container">
			<h3>Change Theme Color</h3>
			<input id="color-input-theme" type="color" min="0" max="255" value="<?php echo $_SESSION['view_settings']['sitecolor']; ?>"><br>
			<form action="assets/functions.php" name="change_color" method="post" enctype="multipart/form-data">
				<div class="input_control">
					<label for="color">Theme Color</label>
					<input id="themecolorinput" type="text" name="color" value="<?php echo $_SESSION['view_settings']['sitecolor']; ?>">
					<br />					
				</div>
				<input id="color-input-theme-hover" type="color" min="0" max="255" value="<?php echo $_SESSION['view_settings']['sitecolorhover']; ?>"><br>
				<div class="input_control">
					<label for="colorhover">Theme Color Hover</label>
					<input id="themehovercolorinput" type="text" name="colorhover" value="<?php echo $_SESSION['view_settings']['sitecolorhover']; ?>">
					<br />					
				</div>
				<input type="checkbox" name="change_color" style="display: none;" checked="true">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

		<div class="tool_container">
			<h3>Change Note Text Color</h3>
			<input id="color-input-note" type="color" min="0" max="255" value="<?php echo $_SESSION['view_settings']['notecolor']; ?>"><br>
			<form action="assets/functions.php" name="change_notecolor" method="post" enctype="multipart/form-data">
				<div class="input_control">
					<label for="notecolor">Note Color</label>
					<input id="notecolorinput" type="text" name="notecolor" value="<?php echo $_SESSION['view_settings']['notecolor']; ?>">
					<br />					
				</div>
				<input type="checkbox" name="change_notecolor" style="display: none;" checked="true">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

		<div class="tool_container">
			<h3>Change Bookmarks Colors</h3>
			<form action="assets/functions.php" name="change_bookmarkscolor" method="post" enctype="multipart/form-data">
				<input id="color-input-bookmarks" type="color" min="0" max="255" value="<?php echo $_SESSION['view_settings']['bookmarkstextcolor']; ?>"><br>
				<div class="input_control">
					<label for="bookmarkstextcolor">Text Color</label>
					<input id="bookmarkscolorinput" type="text" name="bookmarkstextcolor" value="<?php echo $_SESSION['view_settings']['bookmarkstextcolor']; ?>">
					<br />					
				</div>
				<div class="flex-row">
					<?php
					$rgb = $_SESSION['view_settings']['bookmarksbackground'];
					$rgb = str_replace('rgba(', '', $rgb);
					$rgb = str_replace('rgb(', '', $rgb);
					$rgb = str_replace(')', '', $rgb);
					$hex_arr = explode(',', $rgb);
					$hex_value = '#'.dechex((int)$hex_arr[0]).dechex((int)$hex_arr[1]).dechex((int)$hex_arr[2]);
					(int)$opacity = isset($hex_arr[3]) ? $hex_arr[3]*100 : 100;
					?>
					<input id="color-input-bookmarksbg" type="color" value="<?php echo $hex_value; ?>" min="0" max="255"><br>
					<input id="opacity-input-bookmarksbg" type="range" value="<?php echo $opacity; ?>" min="0" max="100">
					<div class="sample-bookmarksbg" style="background: <?php echo $_SESSION['view_settings']['bookmarksbackground']; ?>"></div>
				</div>
				<div class="input_control">
					<label for="bookmarksbackground">Background Color</label>
					<input id="bookmarksbgcolorinput" type="text" name="bookmarksbackground" value="<?php echo $_SESSION['view_settings']['bookmarksbackground']; ?>">
					<br />					
				</div>
				<input type="checkbox" name="change_bookmarkscolor" style="display: none;" checked="true">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

		<div class="tool_container">
			<h3>Change Background Image</h3>
			<form action="assets/functions.php" name="change_mainbackground" method="post" enctype="multipart/form-data">
				<div class="input_control">
					<label for="filetoupload">Image</label>
					<input type="file" name="filetoupload" accept="image">
					<br />
				</div>
				<input type="text" name="targetdir" value="images/backgrounds/" style="display: none;">
				<input type="checkbox" name="change_mainbackground" style="display: none;" checked="true">
				<div class="submit_control">
					<input type="submit" value="submit" name="submit">
				</div>
			</form>
		</div>

	</div>
</div>
