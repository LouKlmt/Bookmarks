
<header>	
	<div class="left-1of3">
	</div>
	<div class="center-2of3">
		<div class="logo-center font-effect-3d" style="">
		<h1>Bookmarks</h1>
		</div>
	</div>
	<div class="right-3of3">
	</div>
	<div class="toolbox_toggler">
		<div class="tool">
			<i class="fa fa-cog"></i>
		</div>
		<div class="toolbox">
			<?php include("core_files/tools/toolbox.php"); ?>
		</div>
	</div>
</header>