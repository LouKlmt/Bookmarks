<?php
session_start();

$DP_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "bookmarks";

$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS);
if ($con->connect_error) {
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	die();
}
$query = "CREATE DATABASE IF NOT EXISTS `bookmarks` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bookmarks`";
$result = $con->query($query);
$con->close();

$con = new mysqli($DP_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($con->connect_error) {
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	die();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Bookmarks</title>
	<link rel="icon" type="image/png" href="assets/images/icons/favicon.png" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<style type="text/css">
		:root{
			<?php 
			$query = "SELECT * FROM settings";
			$result = $con->query($query);
			if ($result != false && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo $row['color'] != "" ? "--sitecolor: ".$row['color'].";" : "--sitecolor: #00b2ff;";
					echo $row['colorhover'] != "" ? "--sitecolorhover: ".$row['colorhover'].";" : "--sitecolorhover: #00b2ff;";
					echo $row['notecolor'] != "" ? "--notecolor: ".$row['notecolor'].";" : "--notecolor: black;";
					echo $row['bookmarkstextcolor'] != "" ? "--bookmarkstextcolor: ".$row['bookmarkstextcolor'].";" : "--bookmarkstextcolor: black;";
					echo $row['bookmarksbackground'] != "" ? "--bookmarksbackground: ".$row['bookmarksbackground'].";" : "--bookmarksbackground: white;";
					echo $row['mainbackground'] != "" ? "--mainbackground: url(assets/images/backgrounds/".$row['mainbackground'].");" : "--mainbackground: url(assets/images/backgrounds/defaultbg.jpg);";

					$_SESSION['view_settings']['sitecolor'] = $row['color'] != "" ? $row['color'] : "#00b2ff;";
					$_SESSION['view_settings']['sitecolorhover'] = $row['colorhover'] != "" ? $row['colorhover'] : "#00b2ff;";
					$_SESSION['view_settings']['notecolor'] = $row['notecolor'] != "" ? $row['notecolor'] : "black;";
					$_SESSION['view_settings']['bookmarkstextcolor'] = $row['bookmarkstextcolor'] != "" ? $row['bookmarkstextcolor'] : "black;";
					$_SESSION['view_settings']['bookmarksbackground'] = $row['bookmarksbackground'] != "" ? $row['bookmarksbackground'] : "white;";
					$_SESSION['view_settings']['mainbackground'] = $row['mainbackground'] != "" ? "url(assets/images/backgrounds/".$row['mainbackground'].")" : "url(assets/images/backgrounds/defaultbg.jpg);";
				}				
			}else{
				echo "--sitecolor: #00b2ff;";
				echo "--sitecolorhover: #00b2ff;";
				echo "--notecolor: black;";
				echo "--bookmarkstextcolor: black;";
				echo "--bookmarksbackground: white;";
				echo "--mainbackground: url(assets/images/backgrounds/defaultbg.jpg);";

				$_SESSION['view_settings']['sitecolor'] = '#00b2ff';
				$_SESSION['view_settings']['sitecolorhover'] = '#00b2ff';
				$_SESSION['view_settings']['notecolor'] = 'black';
				$_SESSION['view_settings']['bookmarkstextcolor'] = 'black';
				$_SESSION['view_settings']['bookmarksbackground'] = 'white';
				$_SESSION['view_settings']['mainbackground'] = 'url(assets/images/backgrounds/defaultbg.jpg)';
			}
			?>
		}
	</style>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu&effect=3d">
	<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body style="background-image: var(--mainbackground);">

	<div class="container">
		<?php if (isset($_GET['error'])) {
			?>
			<div class="errors">
				<div class="error">
					<?php echo $_GET['error']; ?>
				</div>
			</div>
			<?php
		}
		?>
		<?php if (isset($_GET['msg'])) {
			?>
			<div class="messages">
				<div class="message">
					<?php echo $_GET['msg']; ?>
				</div>
			</div>
			<?php
		}
		?>
		<?php if (isset($_GET['error']) || isset($_GET['msg'])) {
			?>
			<button class="urlresetbtn" onclick="resetindex()"><i class="fa fa-retweet" aria-hidden="true"><p>Reset Index</p></i></button>
			<?php
		} ?>
		<?php include("core_files/headers/header.php"); ?>
		<?php include("core_files/tools/topleftmenu.php"); ?>
		<div class="container">
			<div id="top" class="top">
			</div>
			<div id="content" class="content">
				<div class="left-1of3">
				</div>
				<div class="center-2of3">
					<div class="widgets">
						<?php include("core_files/includes/widgets.php"); ?>
					</div>
				</div>
				<div class="right-3of3">
					<?php include("core_files/includes/note.php"); ?>
				</div>
			</div>
			<div id="bottom" class="bottom">
			</div>
		</div>
	</div>

	<footer>
	</footer>
	<script type="text/javascript" src="assets/js.js"></script>
</body>
</html>
<?php $con->close(); ?>