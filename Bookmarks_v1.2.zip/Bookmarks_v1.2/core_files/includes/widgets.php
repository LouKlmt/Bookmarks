<?php

$query = "SELECT * FROM widgets ORDER BY sort_order ASC";
$result = $con->query($query);

if ($result != false && $result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		?>
		<div class="widget">
			<a href="<?php echo $row['href']; ?>" target="_blank"><img alt="<?php echo $row['name']; ?>" src="assets/images/widgets/<?php echo $row['image']; ?>"></a>
		</div>
		<?php
	}				
}


?>